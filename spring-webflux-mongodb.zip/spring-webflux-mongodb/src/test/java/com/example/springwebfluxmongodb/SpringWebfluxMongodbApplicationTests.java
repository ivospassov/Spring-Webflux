package com.example.springwebfluxmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebfluxMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
